var path = require('path');
/**
 * creat
 */
function creat(rootPath){
    var _rootPath = rootPath;
    return function(p){
        return path.join(_rootPath, p);
    };
}

/**
 * get absolte full path
 */
function get(p){
    return path.join(__dirname, '../..', p);
}

exports.get = get;
exports.g = get;
exports.creat = creat;