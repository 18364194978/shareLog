* Absolute Path

** usage

npm install abspath --save

** example

var absPath = require('abspath');
assert(absPath.get('./filename.txt') === '/some/path/to/cur/postion/filename.txt');

or

var absPath = require('abspath').creat(__dirname);
console.log(absPath('filename.txt'));